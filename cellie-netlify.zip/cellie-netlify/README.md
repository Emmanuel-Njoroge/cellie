# Cellie Classroom (Netlify)

Biomedical learning app for kids (Kindergarten, Middle, High school levels) with:
class codes, saved student progress, a live class board, weekly accuracy and points
leaderboards, and a teacher dashboard. Progress is stored on Netlify with Netlify Blobs.

```
public/index.html              the whole app (static)
netlify/functions/api.mjs      the API (class codes, logins, progress, live board, teacher tools)
netlify.toml                   tells Netlify where things are
package.json                   one dependency: @netlify/blobs
```

## Deploy (pick ONE way)

### A. From GitHub (no terminal needed after the first push)
1. Create a new GitHub repository and upload everything in this folder.
2. In Netlify: **Add new site > Import an existing project > GitHub** and pick the repo.
3. Leave the build command empty. Publish directory `public` and functions directory
   `netlify/functions` are read from `netlify.toml`. Click **Deploy**.
4. Open the site URL. Done. (Netlify Blobs needs no setup.)

### B. With the Netlify CLI
```
npm install
npx netlify login
npx netlify init        # create and link a new site
npx netlify deploy --prod
```

> Do not use drag-and-drop "Netlify Drop" for this project. Drop is for static files
> and the API function (which needs its npm package bundled) will not run reliably.

### Try it on your computer first
```
npm install
npx netlify dev         # opens http://localhost:8888 with a local Blobs store
```

## Using it
**Teacher:** open the site, tap **I'm a teacher > Create class**. You get a class code
(like `ABC-123`) and a teacher key (like `XXXX-XXXX-XXXX`). The key is shown once and
cannot be recovered, so save it. The dashboard shows who is active, course completion,
accuracy by student and topic, and lets you reset a PIN, remove a student, rename the
class, or export a CSV.

**Students:** open the site, tap **Join my class**, type the code, pick a generated animal
name, level, color, and a 4-number PIN. To continue on another computer, choose
"I've played before" and enter the same name and PIN.

## Optional settings (Netlify > Site configuration > Environment variables)
- `TEACHER_SIGNUP_CODE` : if set, creating a class requires this code, so strangers who
  find the URL cannot create classes.

## Privacy and safety notes
- Students never type a real name. Names are generated ("Brave Otter 21").
- PINs are stored hashed (PBKDF2). Eight wrong PINs lock that account for 10 minutes.
- The class code is the only thing needed to see a class's animal names, points, and live
  activity, so share it only with your class. Teachers can remove any student.
- Treat this as a classroom activity tool, not a system of record. Follow your school's
  rules about student data. Do not collect real names, emails, or other personal details.

## Limits to know about
- The live board refreshes by polling every few seconds. That uses Netlify function
  invocations (check the free-plan allowance if many classes play at once).
- One shared roster file per class keeps the live board fast. It is designed for classes
  up to roughly 100 students.
- All progress lives in Netlify Blobs for your site. Deleting the site deletes the data.
