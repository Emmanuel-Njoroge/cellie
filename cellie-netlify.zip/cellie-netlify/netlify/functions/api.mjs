// Cellie classroom API (Netlify Function v2 + Netlify Blobs).
// Stores: "classes" (class + teacher key hash), "students" (one record per student, with
// progress + PIN hash), "rosters" (one shared roster blob per class used by the live board).
import { getStore } from "@netlify/blobs";

export const config = { path: "/api/*" };

const enc = new TextEncoder();
const ALPHA = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no 0/O/1/I
const MAX_BODY = 200_000;
const ACTIVE_MS = 45_000;
const stores = {
  classes: () => getStore({ name: "classes", consistency: "strong" }),
  students: () => getStore({ name: "students", consistency: "strong" }),
  rosters: () => getStore({ name: "rosters", consistency: "strong" }),
};

const json = (o, s = 200) =>
  new Response(JSON.stringify(o), { status: s, headers: { "content-type": "application/json", "cache-control": "no-store" } });
const fail = (code, s = 400) => json({ error: code }, s);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const rnd = (n) => { const a = new Uint8Array(n); crypto.getRandomValues(a); return [...a].map((v) => ALPHA[v % ALPHA.length]).join(""); };
const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
async function slowHash(secret, salt) {
  const k = await crypto.subtle.importKey("raw", enc.encode(secret), "PBKDF2", false, ["deriveBits"]);
  return hex(await crypto.subtle.deriveBits({ name: "PBKDF2", salt: enc.encode(salt), iterations: 60000, hash: "SHA-256" }, k, 256));
}
const fastHash = async (s) => hex(await crypto.subtle.digest("SHA-256", enc.encode(s)));
const safeEq = (a, b) => { if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false; let d = 0; for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i); return d === 0; };
const normCode = (c) => String(c || "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6);
const normKey = (k) => String(k || "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 12);
const cleanText = (s, n) => String(s ?? "").replace(/[\u0000-\u001f<>]/g, "").replace(/\s+/g, " ").trim().slice(0, n);
const nickKey = (n) => cleanText(n, 24).toLowerCase();
const num = (v, max = 1e7) => { v = Number(v); return Number.isFinite(v) ? Math.max(0, Math.min(max, Math.round(v))) : 0; };
const fmtCode = (c) => c.slice(0, 3) + "-" + c.slice(3);
const fmtKey = (k) => k.match(/.{1,4}/g).join("-");

async function readBody(req) {
  const len = Number(req.headers.get("content-length") || 0);
  if (len > MAX_BODY) throw Object.assign(new Error("too_large"), { status: 413 });
  const text = await req.text();
  if (text.length > MAX_BODY) throw Object.assign(new Error("too_large"), { status: 413 });
  try { return text ? JSON.parse(text) : {}; } catch { throw Object.assign(new Error("bad_json"), { status: 400 }); }
}

/* ---------- shared roster with optimistic concurrency ---------- */
async function updateRoster(code, mutate, tries = 8) {
  const st = stores.rosters();
  for (let i = 0; i < tries; i++) {
    const cur = await st.getWithMetadata(`r/${code}`, { type: "json", consistency: "strong" });
    const data = cur && cur.data ? cur.data : { students: {} };
    if (!data.students) data.students = {};
    if (mutate(data) === false) return true;
    const res = await st.setJSON(`r/${code}`, data, cur ? { onlyIfMatch: cur.etag } : { onlyIfNew: true });
    if (!res || res.modified !== false) return true;
    await sleep(15 + Math.random() * 70 * (i + 1));
  }
  return false;
}
const getRoster = async (code) => {
  const cur = await stores.rosters().get(`r/${code}`, { type: "json", consistency: "strong" });
  return (cur && cur.students) || {};
};

/* ---------- auth helpers ---------- */
async function getClass(code) {
  if (code.length !== 6) return null;
  return await stores.classes().get(`c/${code}`, { type: "json" });
}
async function authTeacher(code, key) {
  const cls = await getClass(code);
  if (!cls) return null;
  const h = await slowHash(normKey(key), cls.keySalt);
  return safeEq(h, cls.keyHash) ? cls : null;
}
async function authStudent(code, id, token) {
  const rec = await stores.students().get(`s/${code}/${cleanText(id, 16)}`, { type: "json" });
  if (!rec || !token) return null;
  const th = await fastHash(String(token));
  return rec.tokens.some((t) => safeEq(t, th)) ? rec : null;
}
async function newToken(rec) {
  const token = rnd(32);
  rec.tokens = [...(rec.tokens || []), await fastHash(token)].slice(-5);
  return token;
}

/* ---------- sanitizers ---------- */
function cleanSummary(s = {}) {
  const stats = {};
  if (s.stats && typeof s.stats === "object") {
    for (const k of Object.keys(s.stats).slice(0, 12)) stats[cleanText(k, 16)] = { c: num(s.stats[k]?.c, 1e6), t: num(s.stats[k]?.t, 1e6) };
  }
  const pts = s.pts || {};
  return {
    nick: cleanText(s.nick, 24), avatar: cleanText(s.avatar, 8), level: ["b", "i", "x"].includes(s.level) ? s.level : "b",
    pts: { b: num(pts.b), i: num(pts.i), x: num(pts.x) }, total: num(s.total), wk: cleanText(s.wk, 10), wc: num(s.wc, 1e6), wt: num(s.wt, 1e6),
    lessons: num(s.lessons, 500), comp: num(s.comp, 100), streak: num(s.streak, 5000), last: cleanText(s.last, 10),
    chap: num(s.chap, 100), vid: num(s.vid, 100), stats,
  };
}
function cleanLive(l = {}) {
  return { act: cleanText(l.act, 80), qa: num(l.qa, 1000), qt: num(l.qt, 1000), sp: num(l.sp), ok: num(l.ok, 1e5), tot: num(l.tot, 1e5), run: num(l.run, 1e4) };
}

/* ---------- routes ---------- */
const routes = {
  async "ping"() { return json({ ok: true, needsSignup: !!process.env.TEACHER_SIGNUP_CODE, now: Date.now() }); },

  async "class/create"(b) {
    const need = process.env.TEACHER_SIGNUP_CODE;
    if (need && String(b.signup || "").trim() !== need) return fail("bad_signup", 403);
    const name = cleanText(b.name, 40);
    if (name.length < 2) return fail("name_required");
    const st = stores.classes();
    let code = "";
    for (let i = 0; i < 10; i++) { const c = rnd(6); if (!(await st.get(`c/${c}`))) { code = c; break; } }
    if (!code) return fail("try_again", 503);
    const key = rnd(12), keySalt = rnd(16);
    await st.setJSON(`c/${code}`, { code, name, keySalt, keyHash: await slowHash(key, keySalt), created: Date.now() }, { onlyIfNew: true });
    return json({ code: fmtCode(code), name, teacherKey: fmtKey(key) });
  },

  async "class/join"(b) {
    const cls = await getClass(normCode(b.code));
    return cls ? json({ name: cls.name, code: fmtCode(cls.code) }) : fail("class_not_found", 404);
  },

  async "class/board"(b) {
    const code = normCode(b.code), cls = await getClass(code);
    if (!cls) return fail("class_not_found", 404);
    const r = await getRoster(code);
    const students = Object.values(r).map(({ stats, ...pub }) => pub);
    return json({ name: cls.name, now: Date.now(), students });
  },

  async "student/register"(b) {
    const code = normCode(b.code), cls = await getClass(code);
    if (!cls) return fail("class_not_found", 404);
    const nick = cleanText(b.nick, 24);
    if (nick.length < 3) return fail("nick_short");
    if (!/^\d{4}$/.test(String(b.pin || ""))) return fail("pin_format");
    const nk = nickKey(nick), idx = `n/${code}/${nk}`, st = stores.students();
    const made = await st.setJSON(idx, { id: "pending" }, { onlyIfNew: true });
    if (made && made.modified === false) return fail("nick_taken", 409);
    const id = rnd(10), salt = rnd(16);
    const rec = { id, code, nick, nk, avatar: cleanText(b.avatar, 8), salt, pinHash: await slowHash(String(b.pin), salt), tokens: [], fails: 0, lockUntil: 0, created: Date.now(), upd: Date.now(), state: null };
    const token = await newToken(rec);
    await st.setJSON(`s/${code}/${id}`, rec);
    await st.setJSON(idx, { id });
    const summary = cleanSummary({ nick, avatar: b.avatar, level: b.level });
    await updateRoster(code, (d) => { d.students[id] = { id, ...summary, upd: Date.now() }; });
    return json({ id, token, className: cls.name, code: fmtCode(code) });
  },

  async "student/login"(b) {
    const code = normCode(b.code), cls = await getClass(code);
    if (!cls) return fail("class_not_found", 404);
    const st = stores.students();
    const idx = await st.get(`n/${code}/${nickKey(b.nick)}`, { type: "json" });
    if (!idx || !idx.id || idx.id === "pending") return fail("login_failed", 401);
    const rec = await st.get(`s/${code}/${idx.id}`, { type: "json" });
    if (!rec) return fail("login_failed", 401);
    if (rec.lockUntil && rec.lockUntil > Date.now()) return fail("locked", 429);
    const ok = safeEq(await slowHash(String(b.pin || ""), rec.salt), rec.pinHash);
    if (!ok) {
      rec.fails = (rec.fails || 0) + 1;
      if (rec.fails >= 8) { rec.lockUntil = Date.now() + 10 * 60_000; rec.fails = 0; }
      await st.setJSON(`s/${code}/${rec.id}`, rec);
      return fail("login_failed", 401);
    }
    rec.fails = 0; rec.lockUntil = 0;
    const token = await newToken(rec);
    await st.setJSON(`s/${code}/${rec.id}`, rec);
    return json({ id: rec.id, token, className: cls.name, code: fmtCode(code), nick: rec.nick, avatar: rec.avatar, state: rec.state });
  },

  async "student/me"(b) {
    const code = normCode(b.code), rec = await authStudent(code, b.id, b.token);
    if (!rec) return fail("unauthorized", 401);
    const cls = await getClass(code);
    if (!cls) return fail("class_not_found", 404);
    return json({ id: rec.id, className: cls.name, nick: rec.nick, avatar: rec.avatar, state: rec.state });
  },

  async "student/save"(b) {
    const code = normCode(b.code), rec = await authStudent(code, b.id, b.token);
    if (!rec) return fail("unauthorized", 401);
    const stateText = JSON.stringify(b.state || {});
    if (stateText.length > 120_000) return fail("too_large", 413);
    rec.state = JSON.parse(stateText);
    rec.upd = Date.now();
    await stores.students().setJSON(`s/${code}/${rec.id}`, rec);
    const sum = cleanSummary(b.summary);
    if (sum.nick) sum.nick = rec.nick; // the name is fixed at registration
    const done = await updateRoster(code, (d) => { d.students[rec.id] = { ...(d.students[rec.id] || {}), id: rec.id, ...sum, nick: rec.nick, upd: rec.upd }; });
    return json({ ok: true, rosterSaved: done });
  },

  async "student/live"(b) {
    const code = normCode(b.code), rec = await authStudent(code, b.id, b.token);
    if (!rec) return fail("unauthorized", 401);
    const now = Date.now();
    const live = b.off ? { ...cleanLive(b.live), ts: 0, act: "Offline" } : { ...cleanLive(b.live), ts: now };
    const comp = num(b.comp, 100);
    await updateRoster(code, (d) => {
      const cur = d.students[rec.id] || { id: rec.id, nick: rec.nick, avatar: rec.avatar, level: "b", pts: { b: 0, i: 0, x: 0 }, total: 0 };
      d.students[rec.id] = { ...cur, live, comp: comp || cur.comp || 0 };
    }, 5);
    return json({ ok: true, now });
  },

  async "student/leave"(b) {
    const code = normCode(b.code), rec = await authStudent(code, b.id, b.token);
    if (!rec) return fail("unauthorized", 401);
    await removeStudent(code, rec);
    return json({ ok: true });
  },

  async "teacher/dashboard"(b) {
    const code = normCode(b.code), cls = await authTeacher(code, b.key);
    if (!cls) return fail("unauthorized", 401);
    const r = await getRoster(code);
    return json({ name: cls.name, code: fmtCode(code), now: Date.now(), activeMs: ACTIVE_MS, students: Object.values(r) });
  },

  async "teacher/rename"(b) {
    const code = normCode(b.code), cls = await authTeacher(code, b.key);
    if (!cls) return fail("unauthorized", 401);
    const name = cleanText(b.name, 40);
    if (name.length < 2) return fail("name_required");
    cls.name = name;
    await stores.classes().setJSON(`c/${code}`, cls);
    return json({ ok: true, name });
  },

  async "teacher/resetpin"(b) {
    const code = normCode(b.code), cls = await authTeacher(code, b.key);
    if (!cls) return fail("unauthorized", 401);
    if (!/^\d{4}$/.test(String(b.pin || ""))) return fail("pin_format");
    const st = stores.students(), rec = await st.get(`s/${code}/${cleanText(b.id, 16)}`, { type: "json" });
    if (!rec) return fail("not_found", 404);
    rec.salt = rnd(16); rec.pinHash = await slowHash(String(b.pin), rec.salt); rec.tokens = []; rec.fails = 0; rec.lockUntil = 0;
    await st.setJSON(`s/${code}/${rec.id}`, rec);
    return json({ ok: true });
  },

  async "teacher/remove"(b) {
    const code = normCode(b.code), cls = await authTeacher(code, b.key);
    if (!cls) return fail("unauthorized", 401);
    const rec = await stores.students().get(`s/${code}/${cleanText(b.id, 16)}`, { type: "json" });
    if (!rec) return fail("not_found", 404);
    await removeStudent(code, rec);
    return json({ ok: true });
  },
};

async function removeStudent(code, rec) {
  const st = stores.students();
  await st.delete(`s/${code}/${rec.id}`);
  await st.delete(`n/${code}/${rec.nk}`);
  await updateRoster(code, (d) => { delete d.students[rec.id]; });
}

export default async (req) => {
  try {
    const path = new URL(req.url).pathname.replace(/^\/api\//, "").replace(/\/+$/, "");
    const handler = routes[path];
    if (!handler) return fail("not_found", 404);
    if (path !== "ping" && req.method !== "POST") return fail("method_not_allowed", 405);
    const body = path === "ping" ? {} : await readBody(req);
    return await handler(body);
  } catch (e) {
    if (e && e.status) return fail(e.message, e.status);
    console.error("api error", e);
    return fail("server_error", 500);
  }
};
